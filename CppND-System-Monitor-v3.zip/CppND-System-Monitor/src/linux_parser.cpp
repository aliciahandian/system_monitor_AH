#include <dirent.h>
#include <unistd.h>
#include <sstream>
#include <string>
#include <vector>

#include "linux_parser.h"

using std::stof;
using std::string;
using std::to_string;
using std::vector;

// DONE: An example of how to read data from the filesystem
string LinuxParser::OperatingSystem() {
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' '); //by removing the equal sign, we can use the space as a delimeter when tokenizing the strings from each line
      std::replace(line.begin(), line.end(), '"', ' ');
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}

// DONE: An example of how to read data from the filesystem
string LinuxParser::Kernel() {
  string os, kernel, version;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> version >> kernel;
  }
  return kernel;
}

// BONUS: Update this to use std::filesystem
vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename); 										//stoi() converts string token to int
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}

// TODO: Read and return the system memory utilization
float LinuxParser::MemoryUtilization() { 
  
  string line;
  string key;
  string bytes;
  float memTotal;
  float memFree;
  
  std::ifstream filestream(kProcDirectory + kMeminfoFilename);
  if (filestream.is_open()) {	
    //check if file opened successfully
    while (std::getline(filestream, line)) {        //while there are still lines available to read
      
      std::istringstream linestream(line);          //store the line in its own stream
      
      while (linestream >> key >> bytes) {          //while we have two consecutive tokens in the linestream (this should be ok since the key and bytes are separated by spaces)
        
        if (key == "MemTotal:") 
          memTotal = stof(bytes);			   //if key is MemTotal: then store the bytes in a float call memTotal
		  
        if(key == "MemFree:")
          memFree = stof(bytes);			   //if key is MemFree: then store the bytes in a float call memFree
          
        }
      }
    }
  
  float numerator =  (memTotal - memFree);
  float denominator = (memTotal);
  return numerator/denominator;	 // return the difference of the total memory and free memory 
                                                     //(this should be the amount of memory that's used out of the total)
                                                     // divide by 100 to go from kB to MB
}

// TODO: Read and return the system uptime
long LinuxParser::UpTime() {
  
  string uptime, idletime;
  string line;
  std::ifstream stream(kProcDirectory + kUptimeFilename);    //access /proc/uptime
  
  if (stream.is_open()) {					//while there is a string availible to read  in this file
    
    std::getline(stream, line);
    std::istringstream linestream(line);	//put the string into its own stringstream
    
    linestream >> uptime >> idletime;		//tokenize the stringstream, uptime and idletime are separated by spaces so this should be okay
  }
  
  return stol(uptime);                      //convert the uptime string to a long before returning it as an output
}


// TODO: Read and return the number of jiffies for the system
long LinuxParser::Jiffies() { 
  
  return LinuxParser::ActiveJiffies() + LinuxParser::IdleJiffies();   //total jiffies in the system should be a sum of the active and idle jiffies, so we just call those functions and return the sum :)
  
}


// TODO: Read and return the number of active jiffies for a PID
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::ActiveJiffies(int pid) {   
  
  long utime, stime, cutime, cstime;
  vector<string> tokens;
  string next_token;  
  string line;
  
  std::ifstream filestream(kProcDirectory +  std::to_string(pid) + kStatFilename);          // goes to /proc / {pid} /stat  
                                                                                            
  if (filestream.is_open()) {	                                                            // we want a sum of utime and stime which are the 14th and 15th tokens in this file
    
     std::getline(filestream, line);
     std::istringstream linestream(line);             //put text into its own string stream, this file is technically one line so we don't need a loop?
     
     while (linestream >> next_token ){               //while there are remaining tokens to read in the line?
       
       tokens.push_back(next_token);                  //we add each token from the stringstream to an array? result should be an array of tokens
       
      }
    
    utime = stol(tokens[13]);    // utime is the 14th token in the file, so it should be the 13th element of the token array since indeces start from 0 in c++
  	stime = stol(tokens[14]);    // stime is the 15th token in the file, so it should be the 14th element of the token array since indeces start from 0 in c++
    cutime = stol(tokens[15]);    // cutime is the 16th token in the file, so it should be the 15th element of the token array since indeces start from 0 in c++
    cstime = stol(tokens[16]);   // cstime is the 17th token in the file, so it should be the 16th element of the token array since indeces start from 0 in c++
  

  return utime + stime + cutime + cstime;     // the active jiffies for a pid is a sum of the time spent in user code (utime) and time spent in kernel code (stime) ??
                                              // include children processes time as well

  }  
  
  return 0;          // avoid "control reaches end of non-void function -wreturn-type" error by returning a blank value if the file *isn't* open

}



// TODO: Read and return the number of active jiffies for the system
long LinuxParser::ActiveJiffies() {
  
  string key, normal, niced, system, idle, iowait, irq, softirq, steal, guest;
  string line;
  std::ifstream filestream(kProcDirectory + kStatFilename);          // goes to /proc/stat
  
  if (filestream.is_open()) {						//check if file opened successfully
    while (std::getline(filestream, line)) {        //while there are still lines available to read
      
      std::istringstream linestream(line);          //store the line in its own stream
      
      while (linestream >> key >> normal >> niced >> system >> idle >> iowait >> irq >> softirq >> steal >> guest ) {    //while we have ALL consecutive tokens in the linestream 
        																											     //(this should be ok since they are separated by spaces)        
        if (key == "cpu") {
          return stol(normal) + stol(niced)	+ stol(system) + stol(irq) + stol(softirq) + stol(steal);                    //if key is cpu then return sum of non-idle/wait jiffies 
                                                                                                                         //(NOT SURE IF THIS IS EVEN THE CORRECT MATH AT THE MOMENT)
		  
          }
        }
      }
   }
  
  return 0; // avoid "control reaches end of non-void function -wreturn-type" error by returning a blank value if the file *isn't* open
  
}

// TODO: Read and return the number of idle jiffies for the system
long LinuxParser::IdleJiffies() { 
  
  
  string key, normal, niced, system, idle, iowait, irq, softirq, steal, guest;
  string line;
  std::ifstream filestream(kProcDirectory + kStatFilename);          // goes to /proc/stat
  
  if (filestream.is_open()) {						//check if file opened successfully
    while (std::getline(filestream, line)) {        //while there are still lines available to read
      
      std::istringstream linestream(line);          //store the line in its own stream
      
      while (linestream >> key >> normal >> niced >> system >> idle >> iowait >> irq >> softirq >> steal >> guest ) {    //while we have ALL consecutive tokens in the linestream 
        																											     //(this should be ok since they are separated by spaces)        
        if (key == "cpu") {
          return stol(idle) + stol(iowait);                                                                              //if key is cpu then return sum of specifically idle jiffies 
		  
          }
        }
      }
   }
  
  return 0; // avoid "control reaches end of non-void function -wreturn-type" error by returning a blank value if the file *isn't* open
  
}



// TODO: Read and return CPU utilization
vector<string> LinuxParser::CpuUtilization() {                              
  
  string key, normal, niced, system, idle, iowait, irq, softirq, steal, guest;
  string line;
  std::ifstream filestream(kProcDirectory + kStatFilename);          // goes to /proc/stat
  
  if (filestream.is_open()) {						//check if file opened successfully
    while (std::getline(filestream, line)) {        //while there are still lines available to read
      
      std::istringstream linestream(line);          //store the line in its own stream
      
      while (linestream >> key >> normal >> niced >> system >> idle >> iowait >> irq >> softirq >> steal >> guest ) {    //while we have ALL consecutive tokens in the linestream 
        																											     //(this should be ok since they are separated by spaces)        
        if (key == "cpu") {
          return {normal, niced, system, idle, iowait, irq, softirq, steal, guest} ;                                     //if key is cpu then return a vector of all jiffies??? Do we use this function
                                                                                                                         //to keep track of values necessary to calculate CPU utilization in later implementations?
          }                                                                                                              //we can then call this function and use the array to assign previous/current values to calculate
        }                                                                                                                //the cpu utilization as a % over time?
      }
   }
  
  return {" "}; // avoid "control reaches end of non-void function -wreturn-type" error by returning a blank value if the file *isn't* open
  
}


// TODO: Read and return the total number of processes
int LinuxParser::TotalProcesses() {
  
  string key, processes;
  string line;
  std::ifstream filestream(kProcDirectory + kStatFilename);          // goes to /proc/stat
  
  if (filestream.is_open()) {						//check if file opened successfully
    while (std::getline(filestream, line)) {        //while there are still lines available to read
      
      std::istringstream linestream(line);          //store the line in its own stream
      
      while (linestream >> key >> processes) {     //while we have two consecutive tokens in the linestream 
        											//(this should be ok since they are separated by spaces)        
        if (key == "processes") {
          return stoi(processes);                 //if key is processes then return token <processes> (which should be the actual number) after casting it to an int
		  
          }
        }
      }
   }
  
  return 0; // avoid "control reaches end of non-void function -wreturn-type" error by returning a blank value if the file *isn't* open
  
}



// TODO: Read and return the number of running processes
int LinuxParser::RunningProcesses() { 	 
  
  string key, procs_running;
  string line;
  std::ifstream filestream(kProcDirectory + kStatFilename);          // goes to /proc/stat
  
  if (filestream.is_open()) {						//check if file opened successfully
    while (std::getline(filestream, line)) {        //while there are still lines available to read
      
      std::istringstream linestream(line);          //store the line in its own stream
      
      while (linestream >> key >> procs_running) {     //while we have two consecutive tokens in the linestream 
        											   //(this should be ok since they are separated by spaces)        
        if (key == "procs_running") {
          return stoi(procs_running);                  //if key is procs_running then return token <procs_running> (which should be the actual number) after casting it to an int
		  
        }                                                                                                              
      }                                                                                                               
    }
  }  
  
  return 0; // avoid "control reaches end of non-void function -wreturn-type" error by returning a blank value if the file *isn't* open
  
}


// TODO: Read and return the command associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Command(int pid) {              
  
  string line;
  std::ifstream filestream(kProcDirectory +  std::to_string(pid) + kCmdlineFilename);          // goes to /proc / {pid} /cmdline
  
  if (filestream.is_open()) {						            //check if file opened successfully
    while (std::getline(filestream, line)) {                    //while there are still lines available to read
      
      		 return line;                                       //in this case, there should only be one line in the file (this line is the cmnline input) so we can just return it outright
          }
     }
  
  return " "; // avoid "control reaches end of non-void function -wreturn-type" error by returning a blank value if the file *isn't* open
  
}

// TODO: Read and return the memory used by a process
// REMOVE: [[maybe_unused]] once you define the function 
string LinuxParser::Ram(int pid) {                          
  
  string key, ram;
  string line;
  std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatusFilename);          // goes to /proc / {pid} /status
  
  if (filestream.is_open()) {						//check if file opened successfully
    while (std::getline(filestream, line)) {        //while there are still lines available to read
      
      std::istringstream linestream(line);          //store the line in its own stream
      
      while (linestream >> key >> ram  ) {          //while we have two consecutive tokens in the linestream 
        																											             
        if (key == "VmSize:") {                     //find correct line in file -> VmSize ( tells us memory utilization )
          return ram;                                     
                                                                                                                         
       }                                                                                                              
      }                                                                                                               
    }
  }  
  
  return " "; // avoid "control reaches end of non-void function -wreturn-type" error by returning a blank value if the file *isn't* open
  
}

// TODO: Read and return the user ID associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Uid(int pid) {         
  
  string key, UID;
  string line;
  std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatusFilename);          // goes to /proc / {pid} /status
  
  if (filestream.is_open()) {						//check if file opened successfully
    while (std::getline(filestream, line)) {        //while there are still lines available to read
      
      std::istringstream linestream(line);          //store the line in its own stream
      
      while (linestream >> key >> UID  ) {          //while we have two consecutive tokens in the linestream 
        																											             
        if (key == "Uid:") {                        //find correct line in file -> Uid: tells us user ID
          return UID;                                     
                                                                                                                         
        }                                                                                                              
      }                                                                                                               
    }
  }  
  
  return " "; // avoid "control reaches end of non-void function -wreturn-type" error by returning a blank value if the file *isn't* open
  
}

// TODO: Read and return the user associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::User(int pid) {                         
  
  string uid = LinuxParser::Uid(pid);                        //store the UID for this pid in a string
  string username = "lol";
  string letter_x, id; 
  string line;
  std::ifstream filestream(kPasswordPath);                 // goes to /etc/passwd
  
  if (filestream.is_open()) {						         //check if file opened successfully
    while (std::getline(filestream, line)) {                 //while there are still lines available to read
      
      std::replace(line.begin(), line.end(), ':', ' ');      //replace colons with spaces so we can tokenize
      std::istringstream linestream(line);                   //store the line in its own stream
          
      while (linestream >> username >> letter_x >> id  ) {          //while we have three consecutive tokens in the linestream, the pid should be the third token after username ( username:x:{pid} )
              																											             
        if ( id == uid ) {                                   //find the correct line in file where we see username:x:{pid}, see if the UID is in that line 
                                                             //(id is the name of the token where the uid should be, we check to see if it matches what we want)
          return username;                                        //return the username that corresponds to the correct uid                                  
                                                                                                                         
        }                                                                                                              
      }                                                                                                               
    }
  }   
  
  return uid; // avoid "control reaches end of non-void function -wreturn-type" error by returning a blank value if the file *isn't* open
  
}

// TODO: Read and return the uptime of a process
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::UpTime(int pid) {                         
  
  long starttime;
  vector<string> tokens;
  string next_token;  
  string line;
  
  std::ifstream filestream(kProcDirectory + std::to_string(pid) + kStatFilename);          // goes to /proc / {pid} /stat  
                                                                                            
  if (filestream.is_open()) {	                                                            // we want a sum of utime and stime which are the 14th and 15th tokens in this file
    
     std::getline(filestream, line);
     std::istringstream linestream(line);             //put text into its own string stream, this file is technically one line so we don't need a loop?
     
     while (linestream >> next_token ){               //while there are remaining tokens to read in the line?
       
       tokens.push_back(next_token);                  //we add each token from the stringstream to an array? result should be an array of tokens
       
      } 
    }  
  
   starttime = stol(tokens[21]);    // starttime is the 22th token in the file, so it should be the 21th element of the token array since indeces start from 0 in c++

   return starttime;                // return start time
  
}
