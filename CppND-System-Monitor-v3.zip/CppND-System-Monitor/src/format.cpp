#include <string>
#include <sstream>
#include <iomanip>
#include <iostream>

#include "format.h"

using std::string;

// TODO: Complete this helper function
// INPUT: Long int measuring seconds
// OUTPUT: HH:MM:SS
// REMOVE: [[maybe_unused]] once you define the function
string Format::ElapsedTime(long seconds) { 
  
  long h, m;
  
  h = (seconds -(seconds % 3600))/3600;               //the number of hours from seconds is seconds/3600, we want a clean division so we'll subract the remainder from the total before dividing
  seconds = seconds - (h*3600);                       //subtract the seconds from h from the total (we want whatever is left over after accounting for the hours)
  
  m = (seconds -(seconds % 60))/60;                   //the number of minutes from seconds is seconds/60, again we'll take the remainder;
  seconds = seconds - (m*60);                         //subtract the minutes from the total seconds left to get the remaining seconds
  
  std::ostringstream time;
  
  time << std::setfill('0') << std::setw(2) << h << ":"  << std::setfill('0') << std::setw(2) << m <<  ":" << std::setfill('0') << std::setw(2) << seconds << " " ;   
  
    //the std::setfill and std::setw basically make sure that all tokens in the string stream                                                                                             
    //are formatted to be two characters long with 0s filling the blank spots
  
  return  time.str(); 
  
}