#include <unistd.h>
#include <cstddef>
#include <set>
#include <string>
#include <vector>

#include "process.h"
#include "processor.h"
#include "system.h"

using std::set;
using std::size_t;
using std::string;
using std::vector;

/*You need to complete the mentioned TODOs in order to satisfy the rubric criteria "The student will be able to extract and display basic data about the system."

You need to properly format the uptime. Refer to the comments mentioned in format. cpp for formatting the uptime.*/

// TODO: Return the system's CPU
Processor& System::Cpu() { 
  
  return cpu_;                                          //nothing to do here, the functions and Processor object are implemented in line 38 on ncurses.cpp
}

// TODO: Return a container composed of the system's processes
vector<Process>& System::Processes() { 
  
  processes_.clear();                                   //make sure array is empty to start
  
  
  for ( int i : LinuxParser::Pids() ){                  //take each pid from the array of pids for the system 
     
    Process temp(i);                                    //make a new Processor object that has it's pid_ value initialized to the corresponding pid from the LinuxParser array
    processes_.emplace_back(temp);                      //add this object to the processes_ array
    
  }
    
  std::sort(processes_.begin(), processes_.end());
  return processes_;                                    //return what should be an array of Process objects with pids that correspond to the pids from the LinuxParser array
  
}

// TODO: Return the system's kernel identifier (string)
std::string System::Kernel() {
   
  return LinuxParser::Kernel();                         //returns systems kernel identifier   
}

// TODO: Return the system's memory utilization
float System::MemoryUtilization() { 
  
  return LinuxParser::MemoryUtilization();              //returns system memory utilization
}

// TODO: Return the operating system name
std::string System::OperatingSystem() { 
  
  return LinuxParser::OperatingSystem();                //returns OS name
} 

// TODO: Return the number of processes actively running on the system
int System::RunningProcesses() { 
  
  return LinuxParser::RunningProcesses();               //returns total number of running processes on the system
}

// TODO: Return the total number of processes on the system
int System::TotalProcesses() { 
  
  return LinuxParser::TotalProcesses();                 //returns number of running processes on the system
}

// TODO: Return the number of seconds since the system started running
long int System::UpTime() {
  
  return LinuxParser::UpTime();                         //returns system uptime which is already in seconds
}
