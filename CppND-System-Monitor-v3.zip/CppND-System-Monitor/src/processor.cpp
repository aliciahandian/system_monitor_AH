#include "processor.h"
#include <thread>         // std::this_thread::sleep_for
#include <chrono>         // std::chrono::seconds
 
// TODO: Return the aggregate CPU utilization
float Processor::Utilization() { 
	
    normal = stof(LinuxParser::CpuUtilization()[0]);        //set system values by calling using LinuxParser function to
    niced = stof(LinuxParser::CpuUtilization()[1]);         //generate the array of values and then assigning each variable appropriately;
    system = stof(LinuxParser::CpuUtilization()[2]);        //the array elements are strings so we have to convert them to floats
    idle = stof(LinuxParser::CpuUtilization()[3]); 
    iowait = stof(LinuxParser::CpuUtilization()[4]); 
    irq = stof(LinuxParser::CpuUtilization()[5]);
    softirq = stof(LinuxParser::CpuUtilization()[6]);
    steal = stof(LinuxParser::CpuUtilization()[7]); 
  
    prevIdle = previdle + previowait;                 //calculate previous total number of idle JIFFIES
    Idle = idle + iowait;                             //calculate current total number of idle JIFFIES
  
    prevNonIdle = prevnormal + prevniced + prevsystem + previrq + prevsoftirq + prevsteal;   //calculate previous total number of active JIFFIES 
    NonIdle = normal + niced + system + irq + softirq + steal;                               //calculate current total number of active JIFFIES 
    
    prevTotal = prevIdle + prevNonIdle;                                                      // calculate previous total
    total = Idle + NonIdle;                                                                  // calculate current total
  
    delta_total = total - prevTotal;
    delta_idle = Idle - prevIdle;
  
    CPU_percentage = (delta_total - delta_idle) / delta_total;
  
  	std::this_thread::sleep_for (std::chrono::seconds(1));
  
    prevnormal = normal;                             //set current values as the previous ones, so that each subsequent call of Processor::Utilization()
    prevniced = niced;                               //will compare values to values from a previous call ---> constant updates! hopefully anyways...
    prevsystem = system;
    previdle = idle;
    previowait = iowait;
    previrq = irq;
    prevsoftirq = softirq;
    prevsteal = steal; 
    
    return CPU_percentage;  
  
}