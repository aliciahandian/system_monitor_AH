#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>
#include <thread>         // std::this_thread::sleep_for
#include <chrono>         // std::chrono::seconds

#include "process.h"

  
using std::string;
using std::to_string;
using std::vector;

// TODO: Return this process's ID
int Process::Pid() {
  
  return pid_;                                       //this appears to be a basic getter function...
  
}

// TODO: Return this process's CPU utilization
float Process::CpuUtilization() const { 

  float active = LinuxParser::ActiveJiffies(pid_);
  float total_uptime;
  float CPU_usage;
  float prev_active;                                   //can't declare these in the header and then reassign them within a const function... so I'm trying to work around that
  float prev_total_uptime;
  
  for(string i : LinuxParser::CpuUtilization()){  
   		 total_uptime = total_uptime + stof(i);        //sum up all the jiffies listed next to cpu: in /proc/stat to get total cpu uptime in jiffies
  }
  
  std::this_thread::sleep_for (std::chrono::microseconds(10));
  
  prev_active = active;                               //set previous values to current ones, similar to logic in processor.cpp
  prev_total_uptime = total_uptime;
  active = LinuxParser::ActiveJiffies(pid_);          //reset active values to more current ones
  
  for(string i : LinuxParser::CpuUtilization()){  
   		 total_uptime = total_uptime + stof(i);        
  }
  
  CPU_usage = (active - prev_active) / (total_uptime - prev_total_uptime);  // using logic from <https://stackoverflow.com/questions/1420426
                                                                            // /how-to-calculate-the-cpu-usage-of-a-process-by-pid-in-linux-from-c/1424556#1424556>
  
  return  CPU_usage ;        
                                
}

// TODO: Return the command that generated this process
string Process::Command() { 
  
  return LinuxParser::Command(pid_);
}

// TODO: Return this process's memory utilization
string Process::Ram() { 
  
  return LinuxParser::Ram(pid_);
}

// TODO: Return the user (name) that generated this process
string Process::User() {
  
  return LinuxParser::User(pid_); 
}

// TODO: Return the age of this process (in seconds)
long int Process::UpTime() {

  long int uptime = (LinuxParser::UpTime()) - (LinuxParser::UpTime(pid_)/sysconf(_SC_CLK_TCK)); 
  
  return uptime;     // divide by clock ticks since the process starttime is stome in jiffies and we want seconds
}

// TODO: Overload the "less than" comparison operator for Process objects
// REMOVE: [[maybe_unused]] once you define the function

bool Process::operator<(Process const& a ) const 
{ 
  return a.CpuUtilization() < this->CpuUtilization();
} 