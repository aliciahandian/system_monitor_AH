#ifndef PROCESSOR_H
#define PROCESSOR_H

#include "linux_parser.h"

using namespace LinuxParser;

class Processor {
 public:
  float Utilization();  // TODO: See src/processor.cpp
  
  Processor(){          // initialize values to 0, I had to initialize the values with a constructor in order to avoid a core dump error 
                        // caused by defining the defalut value below during declaration... not sure why

    prevnormal = 0;
    prevniced = 0;
    prevsystem = 0;
    previdle = 0;
    previowait = 0;
    previrq = 0;
    prevsoftirq = 0;
    prevsteal = 0;
      
  }

  // TODO: Declare any necessary private members
  
  private: 
  
  float normal, niced, system, idle, iowait, irq, softirq, steal;
  float prevnormal, prevniced, prevsystem, previdle, previowait, previrq, prevsoftirq, prevsteal;  //these values are initialized to zero (the first instance of a loop doesn't have an preceding values)
  
  float prevIdle;
  float Idle;
  
  float prevNonIdle;
  float NonIdle;
  
  float prevTotal;
  float total;                // inspired by stack overflow https://stackoverflow.com/questions/23367857/accurate-calculation-of-cpu-usage-given-in-percentage-in-linux/23376195#23376195
  
  float delta_total;
  float delta_idle;
  
  float CPU_percentage;
  
};

#endif