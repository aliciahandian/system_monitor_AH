#ifndef PROCESS_H
#define PROCESS_H

#include <string>
#include "linux_parser.h"
#include <unistd.h>
#include <dirent.h>

using namespace LinuxParser;

/*
Basic class for Process representation
It contains relevant attributes as shown below
*/
class Process {
 public:
  
  Process(int pid) : pid_(pid){
  CpuUtilization(); 
    
  };                                       //added constructor that immediately initialized the pid, immediately calls CpuUtilizations so we can sort properly
  
  int Pid();                               // TODO: See src/process.cpp
  std::string User();                      // TODO: See src/process.cpp
  std::string Command();                   // TODO: See src/process.cpp
  float CpuUtilization() const;            // TODO: See src/process.cpp  ---> declared as const for the sake of the sort function haha
  std::string Ram();                       // TODO: See src/process.cpp
  long int UpTime();                       // TODO: See src/process.cpp
  bool operator<(Process const& a) const;  // TODO: See src/process.cpp

  
  // TODO: Declare any necessary private members
 private:
  
  int pid_;  
  float prev_active;
  float prev_total_uptime;
  
  
};

#endif